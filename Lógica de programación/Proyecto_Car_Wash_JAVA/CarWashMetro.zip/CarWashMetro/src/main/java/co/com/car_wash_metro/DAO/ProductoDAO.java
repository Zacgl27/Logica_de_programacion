package co.com.car_wash_metro.DAO;

public class ProductoDAO {

    public static void asignarCeldaDB(){

    }

}
